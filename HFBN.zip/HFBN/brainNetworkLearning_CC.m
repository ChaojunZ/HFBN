
  %%  
  load('brainNetSet_PC.mat');
%   load('lab184.mat');
  data=brainNetSetPC{1};
%   for i=1:137
%       data{i}=data(:,:,i);
%   end
  nSubj=length(lab);
  nROI=size(data(:,:,1),2);
  lambda=[0 10 20 30 40 50 60 70 80 90 99];
  nPar=length(lambda);
brainNetSetCC=cell(1,nPar);
for n=1:nSubj
    for i=1:116
        for j=1:116
            
        end
    end
end
for L=1:nPar
  brainNet=zeros(nROI,nROI,nSubj);
        for i=1:nSubj
            currentNet=corrcoef(data(:,:,i));
            currentNet=currentNet-diag(diag(currentNet));% no link to oneself
            threhold=prctile(abs(currentNet(:)),lambda(L)); % fractile quantile
            currentNet(find(abs(currentNet)<=threhold))=0;
            brainNet(:,:,i)=currentNet;
        end
        brainNetSetCC{L}=brainNet;
        fprintf('Done %d/%d networks!\n',L,nPar);
end
save('brainNetSet_CC.mat','brainNetSetCC','lab');
  
