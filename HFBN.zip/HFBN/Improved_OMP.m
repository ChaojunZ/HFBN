function[theta, error1]=Improved_OMP(y,A,t)

    [y_rows,y_columns]=size(y);
    if y_rows<y_columns
         y=y';%y should be a column vector
    end
    [M,N]=size(A);                            
     theta=zeros(N,1);                         
     At=zeros(M,t);                           
     Pos_theta=zeros(1,t);                    
     r_n=y;                                   
     error1=zeros(1,t);
     
     
    for ii=1:t                                 
         product=A'*r_n;                      
        [~,pos]=max(abs(product));          
         At(:,ii)=A(:,pos);                    
         Pos_theta(ii)=pos;                    
         a1=rem(pos/3,1);a2=rem(((pos+1)/3),1);a3=rem(((pos+2)/3),1);
         
         if a1<0.1
             A(:,pos)=zeros(M,1);A(:,pos-1)=zeros(M,1);A(:,pos-2)=zeros(M,1); 
         elseif a2<0.1
             A(:,pos)=zeros(M,1);A(:,pos-1)=zeros(M,1);A(:,pos+1)=zeros(M,1);
         else
             A(:,pos)=zeros(M,1);A(:,pos+1)=zeros(M,1);A(:,pos+2)=zeros(M,1);
         end
         
         theta_ls=pinv(At(:,1:ii))*y;                                                         %y=At(:,1:ii)*theta(Least Square)
%          theta_ls=(At(:,1:ii)'*At(:,1:ii))^(-1)*At(:,1:ii)'*y;  
                                                                 
         r_n=y-At(:,1:ii)*theta_ls;            
         error=sum(r_n.^2);
         if error == 0                        
            break;  
         end
        error1(ii)=error;
    end
    for j=1:ii
        Pos(j)=Pos_theta(j);
    end
    theta(Pos)=theta_ls;                   
 end