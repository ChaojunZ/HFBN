%written by Chaojun Zhang.
clc
clear
close all

load brainNetSet_PC.mat;load brainNetSet_CC.mat; load brainNetSet_SR.mat;%Brain network sets based on different net parameters.
W=brainNetSetPC{1};X=brainNetSetSR{1};Z=brainNetSetCC{1};

y=lab';
nSubj=length(lab);
nROI=size(brainNetSetPC{1},2);
t=600;
%%-----------------------------------
%Pull into vectors
data11=zeros(nROI^2,nSubj);
for i=1:nSubj
    originalNet = brainNetSetPC{1}(:,:,i);
    originalNet=originalNet-diag(diag(originalNet));% remove the non-informative diagal elements
    originalNet=(originalNet+originalNet')/2;% symmetrization
    originalNet=triu(originalNet);
    data11(:,i)=reshape(originalNet,nROI^2,1);
end
idx=find(sum(abs(data11'))>1e-12);
%%-----------------------------------

data1 = zeros(nROI^2,nSubj);
for i=1:nSubj
    originalNet = W(:,:,i);
    originalNet=originalNet-diag(diag(originalNet)); % remove the non-informative diagal elements
    originalNet=(originalNet+originalNet')/2; % symmetrization
    originalNet=triu(originalNet);
    data1(:,i)=reshape(originalNet,nROI^2,1);
end
data1=data1(idx,:);
data2 = zeros(nROI^2,nSubj);
for i=1:nSubj
    originalNet = X(:,:,i);
    originalNet=originalNet-diag(diag(originalNet)); % remove the non-informative diagal elements
    originalNet=(originalNet+originalNet')/2; % symmetrization
    originalNet=triu(originalNet);
    data2(:,i)=reshape(originalNet,nROI^2,1);
end
data2=data2(idx,:);
data3 = zeros(nROI^2,nSubj);
for i=1:nSubj
    originalNet = Z(:,:,i);
    originalNet=originalNet-diag(diag(originalNet)); % remove the non-informative diagal elements
    originalNet=(originalNet+originalNet')/2; % symmetrization
    originalNet=triu(originalNet);
    data3(:,i)=reshape(originalNet,nROI^2,1);
end
data3=data3(idx,:);
%Multiple views stitched together
data=zeros(nSubj,2*nROI*(nROI-1)/2);
for i=1:nROI*(nROI-1)/2
    data(:,3*i-2) = data1(i,:)';
    data(:,3*i-1) = data2(i,:)';
    data(:,3*i) = data3(i,:)';
end
data=data';

kfoldout=nSubj; % LOO CV for outer loop
p_value=0.01;
c_out = cvpartition(nSubj,'k',kfoldout); % for outer CV
accnum=0;tp=0;tn=0;
Test_res = zeros(1,kfoldout); % for final test results
for fdout=1:c_out.NumTestSets
    
    Train_dat = data(:,training(c_out,fdout));
    Train_lab = lab(training(c_out,fdout));
    Test_dat = data(:,test(c_out,fdout));
    Test_lab = lab(test(c_out,fdout));
    [Index_out,~]=find(test(c_out,fdout)~=0);%%Find the location of the Subjects used in this study
    MaxV=(max(Train_dat'))';
    MinV=(min(Train_dat'))';
    [R,C]= size(Train_dat);
    Train_dat=2*(Train_dat-repmat(MinV,1,C))./(repmat(MaxV,1,C)-repmat(MinV,1,C))-1;
    [R,C]= size(Test_dat);
    Test_dat=2*(Test_dat-repmat(MinV,1,C))./(repmat(MaxV,1,C)-repmat(MinV,1,C))-1;
%     Train_dat=mapminmax(Train_dat,-1,1);
%     Test_dat=mapminmax(Test_dat,-1,1);
    A = Train_dat';
    theta=Improved_OMP(Train_lab,A,t);
    
%     [predict_label,pre]=predict(theta,Test_dat);
    idx=find(theta>0);
    Train_dat=Train_dat(idx,:);
    Test_dat=Test_dat(idx,:);
    POSITIVE_data = Train_dat(:,Train_lab==1);
    NEGATIVE_data = Train_dat(:,Train_lab==-1);
    [tad,p_tmp] = ttest2(double(POSITIVE_data'), double(NEGATIVE_data'));%t-test
    [ordered_p,indp]=sort(p_tmp);
    index = indp(ordered_p<p_value);
    Train_dat = Train_dat(index,:);
    Test_dat = Test_dat(index,:);
    
%     MaxV=(max(Train_dat'))';
%     MinV=(min(Train_dat'))';
%     [R,C]= size(Train_dat);
%     Train_dat=2*(Train_dat-repmat(MinV,1,C))./(repmat(MaxV,1,C)-repmat(MinV,1,C))-1;
%     [R,C]= size(Test_dat);
%     Test_dat=2*(Test_dat-repmat(MinV,1,C))./(repmat(MaxV,1,C)-repmat(MinV,1,C))-1;
    
    cmd = ['-t 0 -c 1 -q'];% linear kernel
    model = svmtrain(Train_lab', Train_dat', cmd); % Linear Kernel
    
    [predict_label, accuracy_svm, prob_estimates] = svmpredict(Test_lab', Test_dat', model, '-q');
    
%     model = fitcsvm( Train_dat', Train_lab');
%     [predict_label,pre] = predict( model,  Test_dat');
%     
%     model = fitcsvm( Train_dat', Train_lab');
%     [predict_label, ~,] = predict( model,  Test_dat');
    if predict_label==Test_lab
        accnum=accnum+1;
        if predict_label==1
            tp=tp+1;
        end
        if predict_label==-1
            tn=tn+1;
        end
    end
    Test_res(fdout) = sum(predict_label==Test_lab')/length(Test_lab);%accuracy;
    fprintf('current fold=%d.\n',fdout);
    prob(Index_out,1)=prob_estimates;
    ROC(Index_out,1)=prob_estimates(:,1);
end
[~,~,~,auc]=perfcurve(lab,ROC,1);
posnum=sum(lab==1);
nagnum=sum(lab==-1);
f1score=2*tp/(2*tp+nagnum-tn+posnum-tp);
ppv=tp/(tp+nagnum-tn);
npv=tn/(tn+posnum-tp);
sen=tp/posnum;
spe=tn/nagnum;
bac=(sen+spe)*0.5;
acc=accnum/nSubj;
Final_sixindex=[acc,sen,spe,bac,ppv,npv,f1score,auc]